//
//  WZYHistoryClassesViewController.h
//  XingXingEdu
//
//  Created by Mac on 16/5/11.
//  Copyright © 2016年 xingxingEdu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WZYHistoryClassesViewController : UIViewController
@property (nonatomic, copy)NSString *babyId;

@end
